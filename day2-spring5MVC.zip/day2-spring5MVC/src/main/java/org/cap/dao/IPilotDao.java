package org.cap.dao;

import java.util.List;

import org.cap.model.Pilot;

public interface IPilotDao {
	public void SavePilot(Pilot pilot);
	public List<Pilot> getAllPilots();
	public void DeletePilot(int pilotId);
}
