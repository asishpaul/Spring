package org.cap.util;

import java.util.ArrayList;
import java.util.List;

public class PilotUtil {
	
	public static List<String> getAllCities(){
		List<String> cities=new ArrayList<>();
		cities.add("Chennai");
		cities.add("Pune");
		cities.add("Hyderabad");cities.add("Bangalore");
		cities.add("Mubai");
		cities.add("Gurgaon");
		return cities;
		
	}
	
	public static List<String> getQualification(){
		List<String> qualification=new ArrayList<>();
		qualification.add("MBA");
		qualification.add("M.tech");
		qualification.add("Phd");
		return qualification;
		
	}
}
