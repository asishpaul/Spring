package org.cap.service;

import java.util.List;

import org.cap.model.Pilot;

public interface IPilotService {
	public void SavePilot(Pilot pilot);
	public List<Pilot> getAllPilots();
	public void DeletePilot(int pilotId);
}
