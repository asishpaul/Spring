package org.cap.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MyController {
	
	@RequestMapping("/hello")
	public ModelAndView sayHello() {
		String myMessage="Hello! Welcome To Spring5!";
		return new ModelAndView("success", "msg", myMessage);
	}
		
		@RequestMapping("/validate")
		public String validateLogin(@RequestParam("userName")String userName,
				@RequestParam("userPwd")String userPwd,ModelMap map) {
			
			if(userName.equals("tom") && userPwd.equals("tom123") )
			{
				map.addAttribute("username",userName);
				return "success";
			}else		
			return "redirect:/";
		} 

}
