package com.cap.model;

public class Customer {
	
	private String customerId;
	private String CustomerName;
	private String regFees;
	private Address address;
	
	public Customer() {
		
	}

	

	public Customer(String customerId, String customerName, String regFees, Address address) {
		super();
		this.customerId = customerId;
		CustomerName = customerName;
		this.regFees = regFees;
		this.address = address;
	}



	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return CustomerName;
	}

	public void setCustomerName(String customerName) {
		CustomerName = customerName;
	}

	public String getRegFees() {
		return regFees;
	}

	public void setRegFees(String regFees) {
		this.regFees = regFees;
	}
	 
	public Address getAddress() {
		return address;
	}



	public void setAddress(Address address) {
		this.address = address;
	}



	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", CustomerName=" + CustomerName + ", regFees=" + regFees
				+ ", address=" + address + "]";
	}



	
	
	
}
